Guia para integrar Machine Learning

1 - Criar a pasta Assets

File > New > Folder > Assets Folder

2 - Copiar os arquivos abaixo para a pasta Assets Folder
converted_model.tflite
labels.txt

3 - Modificar no Build Gradle (Module:app)
abaixo de buildTypes {}

 aaptOptions{
        noCompress "tflite"
        noCompress "lite"
    }

acrescentar em:
dependencies{
implementation 'org.tensorflow:tensorflow-lite:0.0.0-nightly'
}

fazer um sync do build

passar a String result do btnCategorizar.setOnClickListener
como um valor para o banco na coluna correspondente.



