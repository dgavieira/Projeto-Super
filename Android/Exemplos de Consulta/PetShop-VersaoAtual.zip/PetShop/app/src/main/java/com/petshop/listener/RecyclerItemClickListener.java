package com.petshop.listener;

import android.view.View;

public interface RecyclerItemClickListener {

    void onItemClick(int position, View view);
}
