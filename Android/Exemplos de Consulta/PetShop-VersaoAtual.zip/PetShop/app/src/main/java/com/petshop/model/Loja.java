package com.petshop.model;

public class Loja {
}
