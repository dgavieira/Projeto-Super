package com.petshop.adapter;

import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.card.MaterialCardView;
import com.petshop.resource.CircleImageView;

public class ItensCompradosView {

    MaterialCardView card;
    CircleImageView img;
    TextView nome;
    TextView preco;
    TextView qnt;
    TextView custoTotal;

}
