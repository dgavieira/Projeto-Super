package com.petshop.listener;

import android.view.View;

public interface RecyclerItemLongClickListener {

    void onItemLongClick(int position, View view);
}
