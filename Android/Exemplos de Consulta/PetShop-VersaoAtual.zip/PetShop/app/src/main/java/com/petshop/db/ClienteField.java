package com.petshop.db;

public class ClienteField {

    public static final String TABLE_NAME = "cliente";
    public static final String COLUMN_ID = "cliente_id";
    public static final String COLUMN_NAME = "cliente_name";
    public static final String COLUMN_PHONE = "cliente_phone";
    public static final String COLUMN_IDADE= "cliente_idade";
    public static final String COLUMN_PHOTO = "cliente_photo";
    public static final String COLUMN_SENHA = "cliente_senha";
    public static final String COLUMN_CPF = "cliente_cpf";
    public static final String COLUMN_EMAIL = "cliente_email";


}
