package com.petshop.adapter;

import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.card.MaterialCardView;

public class ProdutoDetalhesView {

    MaterialCardView card;
    TextView nome;
    ImageView img;
    TextView descricao;

}
